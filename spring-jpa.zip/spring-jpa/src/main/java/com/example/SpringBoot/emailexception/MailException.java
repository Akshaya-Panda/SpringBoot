package com.example.SpringBoot.emailexception;

public class MailException extends Exception{
	
	    /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public MailException(String msg) {
	        super(msg);
	    }
}


